import java.io.*;
import java.security.MessageDigest;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.codec.digest.DigestUtils;;

/**
 * This class is the main class in the program, match hashes with 
 * dictionaries, and output the results.
 * 
 * You need generate all the dictionaries first, and then run this 
 * class.
 * 
 * @author YUANMKAI MA
 *
 */
public class Recover {

	public static int analyzed = 0;
	public static int found = 0;
    
	/**
	 * matchDictionary is used to match single dictionary.
	 * 
	 * @param dictionaryPath The dictionary file path you want to match.
	 * @param hashes         ArrayList of all the hashed password.
	 * @param outPath        The path of output file.
	 */
	public static void matchDictionary(String dictionaryPath,ArrayList<String> hashes,String outPath){
		
	    try {
                String encoding="UTF-8";
                File dicfile=new File(dictionaryPath);
                File outfile=new File(outPath); 
                if(dicfile.isFile() && dicfile.exists()){
                	BufferedWriter  out = new BufferedWriter(new OutputStreamWriter(
            				new FileOutputStream(outfile, true)));
                    InputStreamReader readDic = new InputStreamReader(
                    new FileInputStream(dicfile),encoding);
                    BufferedReader bufferedReader = new BufferedReader(readDic);
                    String lineTxt = null;
                    while((lineTxt = bufferedReader.readLine()) != null){
                        //System.out.println(lineTxt);
                        String shaTxt = DigestUtils.sha256Hex(lineTxt).toUpperCase();
                        for(String hash : hashes)
                        {
                        	if (hash.equals(shaTxt))
            				{
            					out.write(shaTxt+" "+lineTxt+"\r\n");
            					found += 1;
            				}
                        }
                    }
                    readDic.close();
                    out.close();
		        }else{
		           return;
		        }
	        } catch (Exception e) {
	           return;
	        }
	    }
	/**
	 * The matchDictionaries function is used to get all hashes from hashes file, and 
	 * match them with all dictionaries.
	 * 
	 * @param passPath The path of hashes file.
	 * @param outPath  The path of output file.
	 */
	 public static void matchDictionaries(String passPath,String outPath){	 
		 ArrayList<String> hashes = new ArrayList<String>();//get hashes and record in array list
	     try {
	             String encoding="UTF-8";
	             File passFile=new File(passPath);
	            //whether hashes file exists
	             if(passFile.isFile() && passFile.exists()){
	                 InputStreamReader readPass = new InputStreamReader(
	                 new FileInputStream(passFile),encoding);
	                 BufferedReader passbufferedReader = new BufferedReader(readPass);
	                 String pass = null;
	                 while((pass = passbufferedReader.readLine()) != null){
	                	 hashes.add(pass);
	                	 //readPass.close();
	                 }
			     }else{//complain
			         System.out.println("Hashesfile does not exist!");
			         return;
			         
			     }
	     } catch (Exception e) {
	         System.out.println("Hashesfile error!");
	         e.printStackTrace();
	         return;
	     }
	     analyzed = hashes.size();
	    try {               
                File outfile=new File(outPath);
                //whether output file exists
                if (!outfile.exists()) {//create new output file
                	outfile.createNewFile();
                }else{// erase the previous output file
                	FileWriter fileWriter =new FileWriter(outPath);
                    fileWriter.write("");
                    fileWriter.flush();
                    fileWriter.close();
                }  
                //match 4 dictionaries
            	matchDictionary("src/names.txt",hashes,outPath);
                matchDictionary("src/namenumber.txt",hashes,outPath);
                matchDictionary("src/wordlist.txt",hashes,outPath);
                matchDictionary("src/alphanumber.txt",hashes,outPath);
                
	        } catch (Exception e) {
	           return;
	        }
	    }

	public static void main(String[] args){
		// TODO Auto-generated method stub
		 System.out.println("Input hash file and output file:");
		 Scanner scan = new Scanner(System.in);
		 String passPath = "src/"+scan.nextLine();
		 String outPath = "src/"+scan.nextLine();

		long startTime = System.currentTimeMillis(); 

		matchDictionaries(passPath,outPath);

		long endTime = System.currentTimeMillis(); 
		
		System.out.println(" ");
		System.out.println( analyzed +" hashes analyzed, "+found+" passwords found");
		System.out.println("Execution time:" + (endTime - startTime)/1000 + "s");
		
	}

}
