import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.StringUtils;

/**
 * This class is used to generate dictionary 5 automatically, the results
 * are written to "alphanumber.txt"
 * 
 * @author YUANKAI MA
 *
 */
public class Dic5Generate {
	
    
	public static void main(String[] args) throws IOException {
		char array[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_!@#$%^&*"
				.toCharArray();
        StringBuffer password = new StringBuffer();
		char[] temp = new char[4];
		int length = array.length;
		File file = new File("src/alphanumber.txt");
        if (!file.exists()) {
            file.createNewFile();
        }else{
        	FileWriter fileWriter =new FileWriter("src/alphanumber.txt");
            fileWriter.write("");
            fileWriter.flush();
            fileWriter.close();
        }
		BufferedWriter  out = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(file, true)));
		for(int i=0;i<length;i++){
			temp[0] = array[i];
			for(int j=0;j<length;j++){
				temp[1] = array[j];
				for(int k=0;k<length;k++){
					temp[2] = array[k];
					for(int l=0;l<length;l++){
						temp[3] = array[l];
						password.append(temp[0]).append(temp[1]).append(temp[2]).append(temp[3]);
						out.write(password.toString()+"\r\n");
						password.setLength(0);
					}
				}
			}
		}
		out.close();
	}

}
