import java.io.*;
import java.util.*;

import org.apache.commons.codec.digest.DigestUtils;

/**
 * This class is used to generate dictionary 3 automatically, the results
 * are written to "namenumber.txt". File "names.txt" which concludes dictionary 1
 * and 2 is required.
 * 
 * @author YUANKAI MA
 *
 */
public class Dic3Generate {
	
	/**
	 * genMixNames is used to transform name to the string with no specified case 
	 * and with a number up to 9999 at the end.
	 * 
	 * @param lineTxt      The original name you want to transform.
	 * @param file         The dictionary file.
	 * @throws IOException
	 */
	public static void genMixNames(String lineTxt, File file) throws IOException
	 {
		BufferedWriter  out = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(file, true)));
				
		 int num=lineTxt.length();
    	 int n=(int)Math.pow(2,num);
    	 char ch;
    	 for(int i=0;i<n;i++){
        	String tmp=Integer.toBinaryString(i);
        	while(tmp.length()<lineTxt.length()){
        		tmp="0"+tmp;
        	}
        	String result="";
        	for(int j=0;j<tmp.length();j++){
            	char c=tmp.charAt(j);
            	if(c=='1'){
            		ch=(char)((int)lineTxt.charAt(j)-32);
            	}else{
            		ch=lineTxt.charAt(j);
            	}
            	result=result+ch;
        	}
        	for(int number=1;number<=9999;number++)
        	{
        	  String appendTxt = result+number;
        	  out.write(appendTxt+"\r\n");
        	}
    	}
    	 out.close();
	 }
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		File file = null;
        file = new File("src/namenumber.txt");
        if (!file.exists()) {
            file.createNewFile();
        }else{
        	FileWriter fileWriter =new FileWriter("src/namenumber.txt");
            fileWriter.write("");
            fileWriter.flush();
            fileWriter.close();
        }
        String encoding="UTF-8";
        File names = new File("src/names.txt");
        if(names.isFile() && names.exists()){ 
            InputStreamReader read = new InputStreamReader(
            new FileInputStream(names),encoding);
            BufferedReader bufferedReader = new BufferedReader(read);
            String lineTxt = null;
            //int count = 0;
            while((lineTxt = bufferedReader.readLine()) != null){
                genMixNames(lineTxt,file);
            	//System.out.println(count);
            	//count += 1;
            }
            read.close();
	}
	}

}
